/* ==================================== JUCER_BINARY_RESOURCE ====================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

namespace BinaryData
{

//================== logo.svg ==================
static const unsigned char temp_binary_data_0[] =
"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n"
"<!-- Created with Inkscape (http://www.inkscape.org/) -->\n"
"\n"
"<svg\n"
"   xmlns:dc=\"http://purl.org/dc/elements/1.1/\"\n"
"   xmlns:cc=\"http://creativecommons.org/ns#\"\n"
"   xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n"
"   xmlns:svg=\"http://www.w3.org/2000/svg\"\n"
"   xmlns=\"http://www.w3.org/2000/svg\"\n"
"   xmlns:sodipodi=\"http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd\"\n"
"   xmlns:inkscape=\"http://www.inkscape.org/namespaces/inkscape\"\n"
"   width=\"210mm\"\n"
"   height=\"297mm\"\n"
"   viewBox=\"0 0 210 297\"\n"
"   version=\"1.1\"\n"
"   id=\"svg8\"\n"
"   inkscape:version=\"0.92.2 2405546, 2018-03-11\"\n"
"   sodipodi:docname=\"logo.svg\"\n"
"   inkscape:export-filename=\"/home/xevin/Desktop/activez1x/Source/logo.svg.png\"\n"
"   inkscape:export-xdpi=\"96\"\n"
"   inkscape:export-ydpi=\"96\">\n"
"  <defs\n"
"     id=\"defs2\" />\n"
"  <sodipodi:namedview\n"
"     id=\"base\"\n"
"     pagecolor=\"#ffffff\"\n"
"     bordercolor=\"#666666\"\n"
"     borderopacity=\"1.0\"\n"
"     inkscape:pageopacity=\"0.0\"\n"
"     inkscape:pageshadow=\"2\"\n"
"     inkscape:zoom=\"0.32809106\"\n"
"     inkscape:cx=\"556.28104\"\n"
"     inkscape:cy=\"571.35078\"\n"
"     inkscape:document-units=\"mm\"\n"
"     inkscape:current-layer=\"layer3\"\n"
"     showgrid=\"false\"\n"
"     inkscape:window-width=\"1440\"\n"
"     inkscape:window-height=\"826\"\n"
"     inkscape:window-x=\"0\"\n"
"     inkscape:window-y=\"0\"\n"
"     inkscape:window-maximized=\"1\" />\n"
"  <metadata\n"
"     id=\"metadata5\">\n"
"    <rdf:RDF>\n"
"      <cc:Work\n"
"         rdf:about=\"\">\n"
"        <dc:format>image/svg+xml</dc:format>\n"
"        <dc:type\n"
"           rdf:resource=\"http://purl.org/dc/dcmitype/StillImage\" />\n"
"        <dc:title></dc:title>\n"
"      </cc:Work>\n"
"    </rdf:RDF>\n"
"  </metadata>\n"
"  <g\n"
"     inkscape:groupmode=\"layer\"\n"
"     id=\"layer2\"\n"
"     inkscape:label=\"SuperBack\" />\n"
"  <g\n"
"     inkscape:groupmode=\"layer\"\n"
"     id=\"layer9\"\n"
"     inkscape:label=\"Back\">\n"
"    <ellipse\n"
"       style=\"opacity:1;fill:#ffd800;fill-opacity:0.9909091;fill-rule:nonzero;stroke:#ff0007;stroke-width:8.2;stroke-linecap:round;stroke-linejoin:bevel;stroke-miterlimit:18.89999962;stroke-dasharray:16.4,32.8;stroke-opacity:0.99545455;stroke-dashof"
"fset:0\"\n"
"       id=\"path7223\"\n"
"       cx=\"-105.64267\"\n"
"       cy=\"145.39067\"\n"
"       rx=\"104.02981\"\n"
"       ry=\"115.31986\"\n"
"       transform=\"scale(-1,1)\" />\n"
"    <rect\n"
"       style=\"opacity:0;fill:#800080;fill-opacity:1;stroke:#ff0003;stroke-width:1;stroke-linecap:round;stroke-linejoin:bevel;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       id=\"rect836\"\n"
"       width=\"209.67249\"\n"
"       height=\"295.96078\"\n"
"       x=\"0\"\n"
"       y=\"-0.57363701\" />\n"
"  </g>\n"
"  <g\n"
"     inkscape:groupmode=\"layer\"\n"
"     id=\"layer3\"\n"
"     inkscape:label=\"Back 1\" />\n"
"  <g\n"
"     inkscape:label=\"Layer 1\"\n"
"     inkscape:groupmode=\"layer\"\n"
"     id=\"layer1\">\n"
"    <rect\n"
"       id=\"rect3715\"\n"
"       width=\"70.303574\"\n"
"       height=\"71.815475\"\n"
"       x=\"78.619049\"\n"
"       y=\"111.03571\"\n"
"       style=\"stroke-width:8;fill:#ffffff;stroke:#0e8cff;stroke-miterlimit:18.89999962;stroke-dasharray:none;fill-opacity:0;stroke-opacity:1;stroke-linecap:round;stroke-linejoin:bevel\" />\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#0e8cff;stroke-width:8.11188221;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 112.39213,31.660713 -3.10898,5.291667 4.66346,5.291667 -6.9952,4.535714 10.88142,6.047619 -17.876619,10.583333 24.871819,6.803572 -38.084981,15.875 52.852631,-0.755951 -62.956809,25.702376 72.283749,71.81549 V 111.03571 L 76.638871,182.8"
"512 56.430513,116.32738 45.549088,160.92857 32.33593,128.42262 25.340728,151.85714 14.459304,132.95833 8.2413477,145.05357 5.1323695,139.00595\"\n"
"       id=\"path4522\"\n"
"       inkscape:connector-curvature=\"0\" />\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#0e8cff;stroke-width:8.45229244;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 148.80197,111.50404 25.58556,69.56122 -1.70571,-50.11399 11.08707,31.41475 8.52853,-26.17896 5.96997,17.95128 6.8228,-12.71549 2.55856,8.22767\"\n"
"       id=\"path4524\"\n"
"       inkscape:connector-curvature=\"0\" />\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#0e8cff;stroke-width:8.46573162;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 148.5578,182.94078 -68.190412,26.47386 54.702192,11.10196 -35.219216,16.22593 20.232326,9.39395 -16.48561,6.83197 9.7415,5.97798\"\n"
"       id=\"path19\"\n"
"       inkscape:connector-curvature=\"0\" />\n"
"    <rect\n"
"       id=\"rect3715-3\"\n"
"       width=\"70.303574\"\n"
"       height=\"71.815475\"\n"
"       x=\"76.63887\"\n"
"       y=\"111.03571\"\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#0ed6ff;stroke-width:3.60000014;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1;stroke-linecap:round;stroke-linejoin:bevel\" />\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#0ed6ff;stroke-width:3.60000014;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 112.39213,31.660716 -3.10898,5.291667 4.66346,5.291667 -6.9952,4.535714 10.88142,6.047619 -17.876622,10.583333 24.871822,6.803573 -38.084982,15.875 52.852632,-0.755952 -62.956812,25.702373 72.283752,71.81549 v -71.81549 l -72.283752,71.8"
"1549 -20.20836,-66.52382 -10.88142,44.60119 -13.21316,-32.50594 -6.9952,23.43451 -10.88143,-18.89881 -6.2179505,12.09524 -3.10898,-6.04762\"\n"
"       id=\"path4522-5\"\n"
"       inkscape:connector-curvature=\"0\" />\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#0ed6ff;stroke-width:3.60000014;stroke-linecap:round;stroke-linejoin:bevel;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 148.80197,111.50405 25.58556,69.56121 -1.70571,-50.11399 11.08707,31.41475 8.52853,-26.17896 5.96997,17.95128 6.8228,-12.71549 2.55856,8.22767\"\n"
"       id=\"path4524-6\"\n"
"       inkscape:connector-curvature=\"0\" />\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#0ed6ff;stroke-width:3.60000014;stroke-linecap:butt;stroke-linejoin:miter;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 148.5578,182.94078 -68.190412,26.47386 54.702192,11.10197 -35.219222,16.22593 20.232332,9.39394 -16.48561,6.83197 9.7415,5.97798\"\n"
"       id=\"path19-2\"\n"
"       inkscape:connector-curvature=\"0\" />\n"
"    <rect\n"
"       id=\"rect3715-3-6\"\n"
"       width=\"70.303574\"\n"
"       height=\"71.815475\"\n"
"       x=\"76.63887\"\n"
"       y=\"111.03572\"\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#9500fc;stroke-width:1;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1;stroke-linecap:round;stroke-linejoin:bevel\" />\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#9500fc;stroke-width:1;stroke-linecap:round;stroke-linejoin:bevel;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 110.41195,31.660726 -3.10898,5.291667 4.66346,5.291667 -6.9952,4.535714 10.88142,6.047619 -17.876608,10.583335 24.871808,6.80357 -38.084968,15.875 52.852618,-0.75595 -60.976629,25.702362 70.303569,71.81549 V 111.03571 L 76.638871,182.851"
"2 54.450342,116.32738 43.568922,160.92857 30.355759,128.42263 23.36056,151.85714 12.47913,132.95833 l -6.2179511,12.09524 -3.10898,-6.04762\"\n"
"       id=\"path4522-5-2\"\n"
"       inkscape:connector-curvature=\"0\"\n"
"       sodipodi:nodetypes=\"cccccccccccccccccccc\" />\n"
"    <g\n"
"       id=\"g828\"\n"
"       transform=\"translate(-1.8595162,-0.4683468)\">\n"
"      <path\n"
"         inkscape:connector-curvature=\"0\"\n"
"         id=\"path4524-6-6\"\n"
"         d=\"m 148.80196,111.50406 25.58556,69.56121 -1.7057,-50.11399 11.08706,31.41475 8.52853,-26.17896 5.96997,17.95128 6.82281,-12.71549 2.55855,8.22767\"\n"
"         style=\"fill:#ffffff;fill-opacity:0;stroke:#9500fc;stroke-width:1;stroke-linecap:round;stroke-linejoin:bevel;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\" />\n"
"    </g>\n"
"    <path\n"
"       style=\"fill:#ffffff;fill-opacity:0;stroke:#9500fc;stroke-width:1;stroke-linecap:round;stroke-linejoin:bevel;stroke-miterlimit:18.89999962;stroke-dasharray:none;stroke-opacity:1\"\n"
"       d=\"m 148.55779,182.94079 -68.190408,26.47386 54.702188,11.10197 -35.219218,16.22593 20.232328,9.39394 -16.48561,6.83197 9.7415,5.97798\"\n"
"       id=\"path19-2-1\"\n"
"       inkscape:connector-curvature=\"0\" />\n"
"  </g>\n"
"</svg>\n";

const char* logo_svg = (const char*) temp_binary_data_0;


const char* getNamedResource (const char* resourceNameUTF8, int& numBytes)
{
    unsigned int hash = 0;

    if (resourceNameUTF8 != nullptr)
        while (*resourceNameUTF8 != 0)
            hash = 31 * hash + (unsigned int) *resourceNameUTF8++;

    switch (hash)
    {
        case 0x78dee5d0:  numBytes = 8275; return logo_svg;
        default: break;
    }

    numBytes = 0;
    return nullptr;
}

const char* namedResourceList[] =
{
    "logo_svg"
};

const char* originalFilenames[] =
{
    "logo.svg"
};

const char* getNamedResourceOriginalFilename (const char* resourceNameUTF8)
{
    for (unsigned int i = 0; i < (sizeof (namedResourceList) / sizeof (namedResourceList[0])); ++i)
    {
        if (namedResourceList[i] == resourceNameUTF8)
            return originalFilenames[i];
    }

    return nullptr;
}

}
