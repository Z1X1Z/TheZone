#ifndef radial_eq_H_INCLUDED
#define radial_eq_H_INCLUDED
#include "float.h"
#include "../JuceLibraryCode/JuceHeader.h"
#include <vector>
#include "math.h"
#if defined JUCE_WINDOWS
#include <ciso646>
#endif
#define pi 3.1415926535897932384626433832795028841971693993751058
float pi2 =2 * pi;
using namespace std;
class Radial_eq   : public Component, AudioSource, OpenGLRenderer,
                    private Timer
{
public:
   
   // Rectangle<int> dimensions = Desktop::getInstance().getDisplays().getTotalBounds(true);
    float dpiScalar = 1.;//1./Desktop::getInstance().getDisplays().getMainDisplay().scale;


    // ScopedPointer<ThreadPool> pool;
    bool tok, star_on, linked = false;
    int resolution;
    int runTime, static_amp, max_lowest_amp, length = 0;
    float radius, health, shield, breakthrough_amp, trailLength, largest_loop;
    double phase = 0.0f;
    float shipScale = .7;
    float spiroScale =.8;
    float max_zoom = 100000.0;
    vector<vector<float > > spectrum_raw,spectrum_sorted;
    Colour transparent =Colour(  1.f,1.f,1.f,.0f);
    GLfloat zoom = -0.385938;
    bool zoom_in = true;
    GLfloat rainbowizer = 0;
    ScopedPointer<OpenGLShaderProgram> shader;
    ScopedPointer <OpenGLGraphicsContextCustomShader> customShader;
    int frame = 0;
    GLfloat coordy;
    GLfloat coordx;
    int call_back_time = 1000;
    bool shadersOn;
    bool openGLOn;
    bool engineNoiseOn;
    bool pulsingColorsOn;
    int inum = 4;
    bool booting = false;
    bool token = false;
    bool soundOn;
    float angle;
    float d_x;
    float d_y;
    float pitch;
    double amplitude;
    int cycles = 0;
    double links;
    float sensitivity = 1.0f;
    float spirray[10000][2];
    double notes[144]= {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};
    double numOfNotes[144]= {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};
    double testar[24]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    double testarD[24]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    double octave[120], octaveDensity[120]= {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};
    float notes1000[1000], notesBuffer[1000];
    int negatizer [2] = {1,-1};
    Colour centCol;
    struct bubbles
    {
        float radii;
        float ccwiseX;
        float ccwiseY;
        float cwiseX;
        float cwiseY;
        float angle;
        float x;
        float y;
        Colour centCol;
        Colour pitchCol;
    };
    struct spiralColourStruct
    {
        Colour color;
    };

    bubbles trail [1001];
    spiralColourStruct colours[1000];
    float max1 = 0;
    float min1 = 10000000;
    struct soundata {float freq; float amp; float note;};
    static bool sortByNote(soundata &lhs, soundata &rhs) { return lhs.note < rhs.note; }
    float maxOct = 0;





    void newOpenGLContextCreated () override
    {
        // customShader = new OpenGLGraphicsContextCustomShader(fragmentShaderString);
    }

    float on = 1.0f;
    bool tik = false;
    void renderOpenGL() override
    {

        GLfloat height = resy;
        GLfloat width = resx;

        if (!tik) { jassert (OpenGLHelpers::isContextActive()); tik = true;}
        if (zoom < max_zoom and zoom_in) zoom += zoom/100;
        else if(zoom >.2)
        {
            zoom_in = false;
            zoom -= zoom/3.;
        }
        else zoom_in = true;
        //if (pulsingColorsOn)
        //rainbowizer += .002;
        if (linked)
        {
            shader->use();
            shader->setUniform("on", on);

            shader->setUniform("coordy", coordy);
            shader->setUniform("coordx", coordx);
            shader->setUniform("zoom", zoom);
            shader->setUniform("rainbowizer", rainbowizer);
            shader->setUniform("height", height);
            shader->setUniform("width", width);

        }
    }

    void openGLContextClosing() override
    {
        shader.release();
        shader = nullptr;
        customShader = nullptr;

    }

    float tau(float x)
    {
        return 1/4. * log(3*pow(x,2)+ 6*x + 1) - pow(6,.5)/24 * log((x + 1 - pow(2./3 ,2))  /  (x + 1 + sqrt(2./3)));
    }
    float maxFreq = 0;
    float mag (dsp::Complex<float> z){ return pow(pow(z.real(),2)+pow(z.imag(),2),.5);}//
    void spiral_compress()
    {
        maxFreq = 0;
        float freq = 0;
        max1 = 0;
        min1 = 100000;
        double amp;
        for(int n = 0; n<24; n++){testar[n] = 0;testarD[n] = 1;}
        for(int n = 0; n<120; n++){
            octave[n] = 0;
            octaveDensity[n] = 0;
        }
        float b = -1000000;

        auto z = (dsp::Complex<float>*)fftDataC;
        for(int t=2; t<500; t+=1)//n<fftSize1/4-100
        {
            int n =t;
            //if (fftSize1/4<t) n =abs(t-int(t)/(int(fftSize1/4)));
            amp =mag(z[n]);// fftData11[2*n]; //
            if( amp>mag(z[n-1]) and amp > mag(z[n+1]) and not(isnan(mag(amp))) )
            {

                double    ap = (z[n + 1].real()* z[n].real() + z[n+1].imag()* z[n].imag())  /  (z[n].real()* z[n].real() + z[n].imag()* z[n].imag());
                double  dp = -ap / (1 - ap);
                double   am = (z[n - 1].real()* z[n].real() + z[n - 1].imag()* z[n].imag())  /  (z[n].real()* z[n].real() + z[n].imag()* z[n].imag());
                double   dm = am / (1 - am);
                double   d = (dp + dm) / 2 + tau(dp* dp) - tau(dm* dm);
                double nAdj = n;
                if (abs(d)<3) nAdj = n + d;
                //if (abs(nAdj-n) < 10)
                freq =double( double(double(sampleRate/10000.)*double(nAdj))/fftSize1)*10000;

                if(amp>b) {b = amp; maxFreq = freq;}

                if(not(isnan(freq) or isnan(amp) or isinf(amp)) and freq != -33)
                {
                    float g = pow ( 2, (1/24.f));
                    float aa = freq/440.0;
                    float note = log(aa)/log(g)+69*2;
                    testar[int(round(note))%24] += std::abs(amp);
                    testarD[int(round(note))%24] += 1;
                }
            }
        }
        for( int n=0; n<120; n++)  octave[n] /= octaveDensity[n];
        for(int n=0; n<24;++n) {
            double absamp = testar[n];
            if(absamp>max1) {max1 =absamp;}
            if(absamp<min1) min1 = absamp;
        }
        maxOct = 0;
        int maxNN;
        for(int n=0; n<120;n+=1) {
            if(octave[n]>maxOct ) {maxOct = octave[n]; maxNN = n;}}
    };



    bool backgrounded=false;
    int64 timeToSleep;
    int64 timeToLightsOut = 1000*60*8;
    struct touchPitch {float amp = 0;  double phase=0;
        bool dragging = false;
        double lastReduction = 0;
        int sampleNum = 0;
        float shiftFreq = 0;
        float decayBuffer =0;
        double xExit=0;
        double yExit=0;
        String shiftedDir = "out";
        float ampShift=0;
        double exitAngle =0;
        double angle = 0;
        double angleAmp = 0;
        double angleAmpLast = 0;
        double activeAngleAmp = pi2;
        float lastFreq = 0;
        double cumulativeAngleShift = 0;
        String reduced = "not";
        double enterAngle = 0;
        double freqInterp = 0;
        float lastPlayedFreq = 1;
        bool firstDrag = false;
        double freq =1 ; bool pitchJustOff=false;   bool soundJustStarted = true;
        bool pitchOn = false;
        bool pitchChanged = false;};
    touchPitch touchPitches[10];
    float pressAmp = 0;
    float correction = -1.25+.125-.0625+.03125+.2;
    bool closePressed=false;
    float closePressedFor = 0;
    bool ios = false;
    virtual void     mouseDown (    const MouseEvent &event)override
    {
        if (event.getPosition().getX()<minCoord/13. and event.getPosition().getY()<minCoord/13. and ios)
        { closePressed=true;}
        else{
        touchPitch t =touchPitches[event.source.getIndex()];
        t.dragging = false;
        if (!t.pitchJustOff or t.soundJustStarted){touchPitch b; t = b;}
        if(!t.soundJustStarted and !t.pitchOn and !t.pitchJustOff){t.angleAmp =0; t.cumulativeAngleShift = 0;}
        t.soundJustStarted = true;
        t.pitchJustOff = false;
        t.pitchOn = true;
        backgrounded = false;
        timeToSleep = Time::currentTimeMillis()+timeToLightsOut;
        touchPitches[event.source.getIndex()] = t;
        //touchPitches[event.source.getIndex()].angle = getTouchPitch(event);
        touchPitches[event.source.getIndex()].exitAngle = touchPitches[event.source.getIndex()].angle;
        if (t.decayBuffer == 0.)
        {
            touchPitches[event.source.getIndex()].freqInterp = 0;
            //touchPitches[event.source.getIndex()].angleAmp = +touchPitches[event.source.getIndex()].cumulativeAngleShift;
            touchPitches[event.source.getIndex()].enterAngle = 0;
            touchPitches[event.source.getIndex()].exitAngle = 0;
        }
        if(touchPitches[event.source.getIndex()].angle<0)touchPitches[event.source.getIndex()].angle
                                                                 =touchPitches[event.source.getIndex()].angle+2*pi;
        else if (touchPitches[event.source.getIndex()].angle>2*pi)touchPitches[event.source.getIndex()].angle
                                                                          =touchPitches[event.source.getIndex()].angle-2*pi;
        // getTouchPitch(event);



        float x = event.getPosition().getX()-getWidth()/2.;
        float y = event.getPosition().getY()-getHeight()/2.;

        touchPitches[event.source.getIndex()]. pitchChanged = true;
        touchPitches[event.source.getIndex()].exitAngle = atan2(touchPitches[event.source.getIndex()].yExit,
                                                                touchPitches[event.source.getIndex()].xExit);

        touchPitches[event.source.getIndex()].enterAngle = atan2(y,
                                                                 x);

        //  if(!(touchPitches[event.source.getIndex()].exitAngle==0))

        touchPitches[event.source.getIndex()].angleAmp = touchPitches[event.source.getIndex()].cumulativeAngleShift +
                                                         -(touchPitches[event.source.getIndex()].exitAngle)+
                                                         (touchPitches[event.source.getIndex()].enterAngle);
        touchPitches[event.source.getIndex()].angle = getTouchPitch(event);
    }
    }
    float getTouchPitch(  const MouseEvent &event)
    {
        double angle1;
        double x = event.getPosition().getX()-getWidth()/2.;
        double y = event.getPosition().getY()-getHeight()/2.;
        angle1 = atan2(y,x);

        //if (abs(x)<.01 ) angle1 = 0;
        double angle2 = angle1;
        angle2+= pi2*2;
        angle2 += pi/2;

        touchPitches[event.source.getIndex()].angleAmp += pi2*2;
        double reduction =  trunc((touchPitches[event.source.getIndex()].angleAmp)/(pi2))*pi2;
        touchPitches[event.source.getIndex()].angleAmp=
                touchPitches[event.source.getIndex()].angleAmp- reduction;
        angle2=    angle2-int(abs((angle2-  touchPitches[event.source.getIndex()].angleAmp))/(pi2))*pi2;
        touchPitches[event.source.getIndex()].freq = pow (2.,((angle2)/pi/2*12+correction)/12.)/2.*440.;
        if (touchPitches[event.source.getIndex()].reduced != "not")
            touchPitches[event.source.getIndex()].shiftFreq = touchPitches[event.source.getIndex()].freq;

        double freqRation = touchPitches[event.source.getIndex()].freq/touchPitches[event.source.getIndex()].lastFreq;
        // and (freqRation>1.7 or 1/freqRation<1.7)
        if (abs(reduction-18.8496)<.1 and  touchPitches[event.source.getIndex()].reduced != "down")
        {touchPitches[event.source.getIndex()].reduced = "down";
            touchPitches[event.source.getIndex()].freqInterp=touchPitches[event.source.getIndex()].freq;}
        else if (abs(reduction-6.28319)<.1   and    touchPitches[event.source.getIndex()].reduced != "up")
        {
            touchPitches[event.source.getIndex()].reduced = "up";
            touchPitches[event.source.getIndex()].freqInterp=touchPitches[event.source.getIndex()].freq;
    }

        else if      (   abs( touchPitches[event.source.getIndex()].lastReduction-6.28319)<.1
                        and
                abs(reduction-12.5664)<.1)
    touchPitches[event.source.getIndex()].freqInterp =touchPitches[event.source.getIndex()].freq;
        else if      (  abs( reduction-6.28319)<.1
                        and
                        abs(touchPitches[event.source.getIndex()].lastReduction-12.5664)<.1)
            touchPitches[event.source.getIndex()].freqInterp = touchPitches[event.source.getIndex()].freq;

        touchPitches[event.source.getIndex()].lastReduction = reduction;



        return  angle1;
    }
    virtual void  mouseDrag (const MouseEvent &event) override
    {
        touchPitches[event.source.getIndex()].dragging = true;
        double x = event.getPosition().getX()-getWidth()/2.;
        double y = event.getPosition().getY()-getHeight()/2.;

        touchPitches[event.source.getIndex()]. pitchChanged = true;
        touchPitches[event.source.getIndex()].exitAngle = atan2(touchPitches[event.source.getIndex()].yExit,
                                                                touchPitches[event.source.getIndex()].xExit);

        touchPitches[event.source.getIndex()].enterAngle = atan2(y,
                                                                 x);

        //  if(!(touchPitches[event.source.getIndex()].exitAngle==0))

        touchPitches[event.source.getIndex()].angleAmp = touchPitches[event.source.getIndex()].cumulativeAngleShift +
                                                         -(touchPitches[event.source.getIndex()].exitAngle)+
                                                         (touchPitches[event.source.getIndex()].enterAngle);
        touchPitches[event.source.getIndex()].angle = getTouchPitch(event);

    }

    virtual void     mouseUp (    const MouseEvent &event)override
    {

        closePressed = false;
        closePressedFor=0;
        touchPitches[event.source.getIndex()].xExit = event.getPosition().getX()-getWidth()/2.;
        touchPitches[event.source.getIndex()].yExit = event.getPosition().getY()-getHeight()/2.;

        double x = event.getPosition().getX()-getWidth()/2.;
        double y = event.getPosition().getY()-getHeight()/2.;
        touchPitches[event.source.getIndex()].enterAngle = atan2(touchPitches[event.source.getIndex()].yExit,
                                                                 touchPitches[event.source.getIndex()].xExit);

        touchPitches[event.source.getIndex()].exitAngle = atan2(y,
                                                                x);

        if(!(touchPitches[event.source.getIndex()].exitAngle==0))

            touchPitches[event.source.getIndex()].cumulativeAngleShift +=
                    -(touchPitches[event.source.getIndex()].exitAngle)+
                    (touchPitches[event.source.getIndex()].enterAngle);


        touchPitches[event.source.getIndex()].exitAngle = touchPitches[event.source.getIndex()].enterAngle;
        touchPitch t = touchPitches[event.source.getIndex()];
        t.pitchOn = false;
        t.pitchJustOff = true;
        t.soundJustStarted = false;
        touchPitches[event.source.getIndex()] =t ;
    }

    float max_amp=0;
    float moving;
    int movingSpeed = 100;
    bool shrinking;
    float minCoord = 1000000;
    float interpolationFactor;
    float magnitude;

    void move()
    {   float shouldMove = 1;
        float volumeModifier = pow(10,50*maxFrame)/pow(10,50*lastMaxFrame);
        if( volumeModifier < 1)volumeModifier=1;
        if( volumeModifier > 10)volumeModifier=3;
        if (pitch>0)
        {
            magnitude =8*baseMag;
        }
        else shouldMove = 0;

        radius = magnitude;

        if (pitch>1)
        {
            shrinking = false;
            moving ++;
            float g = pow ( 2, (1/24.0));
            float aa = pitch/440.0;
            float note = log(aa)/log(g)+49;
            float inc = 6-.25;
            float t =  (-note * 30+30*inc);
            angle = fmod(t,360);
            trail[0].angle = (angle*pi2/360);
            float brightness=(note+109.5+13)/60.;
            float saturation=1;
            float value = 1;
            if (brightness >= 1) saturation = 2-brightness;
            else value = brightness;
            Colour pitchCol = Colour::fromHSV((angle-60)/360.,saturation,value,1.);
            trail[0].pitchCol = pitchCol;
            d_x = -magnitude/8*-sin(angle*(2*pi)/360)*shouldMove;
            d_y = -magnitude/8*-cos(angle*(2*pi)/360)*shouldMove;
            coordx+=d_x*.001;
            coordy+=d_y*.001;
        }

         if(pitch<1)
        {
            moving = 0;
            shrinking = true;
            trail[0].pitchCol = transparent;

            d_x = 0;
            d_y = 0;
        }
        bubbles trail_buffer[1000];
        trailLength= 25;
        if (playingV)        trailLength= 100;

         interpolationFactor = timeDif*1./(callbackWait-1);
       
        if (interpolationFactor>30) interpolationFactor=30;
        else if (interpolationFactor<1) interpolationFactor=1;

            trail[0].x = 0;
            trail[0].y = 0;

                float xPerp = sin(trail[0].angle-pi/2)/2;
                float yPerp = cos(trail[0].angle - pi / 2) / 2;
                trail[0].radii = radius/2;
        //ccwise(counterclockwise) and cwisce may not be the actual orientation
                trail[0].ccwiseX =  xPerp;
                trail[0].ccwiseY = yPerp;
                trail[0].cwiseX = -xPerp;
                trail[0].cwiseY = -yPerp;


        cycles=trailLength;

        for(int n = 0; n < trailLength; n++)
        {
            trail_buffer[n]=trail[n];
        }

        for(int n = 1; n < trailLength; n++)
        {
            trail[n] =trail_buffer[n-1];
            trail[n].x += d_x*interpolationFactor;
            trail[n].y += d_y*interpolationFactor;
            trail[n].radii *= 1.018;
        }
        for(int n = 0; n < polygons.size(); n++)
        {
            polygons[n].centerX += d_x*interpolationFactor+polygons[n].dx;
            polygons[n].centerY += d_y*interpolationFactor+polygons[n].dy;
            float xFromCent = (polygons[n].centerX-getWidth()/2);
            float yFromCent = (polygons[n].centerY-getHeight()/2);
            float dist = pow(xFromCent*xFromCent+yFromCent*yFromCent,.5);

            if ( dist<minCoord/2.)
            {
                angle = atan2(yFromCent,xFromCent);
                float speed = interpolationFactor*baseMag/202.*(1+atan(pow(metaLevel/2.,level/2.))/pi*2)*.9;
                float speedLimit = baseMag*(1+atan(pow(metaLevel/2.,level/2.))/pi)*.7;

                float currentspeed = pow(polygons[n].dx*polygons[n].dx+polygons[n].dy*polygons[n].dy,.5);



                polygons[n].dx*=.985;
                polygons[n].dy*=.985;

                if (currentspeed+speed<speedLimit)
                {
                    polygons[n].dx+=speed*-(-cos(angle));
                    polygons[n].dy+=speed*-(-sin(angle));
                }

            }
            if ( dist<(polyRad+radius/2*.9)and polygons[n].exited){
                if (!polygons[n].caught)polygons[n].caught = true;
                else polygons[n].caught = false;

                polygons[n].exited = false;}

            else if (dist>polyRad+radius/2*1.2)polygons[n].exited = true;


            if (xFromCent>(getWidth()/2))polygons[n].centerX = -0;
            else if (xFromCent<-(getWidth()/2))polygons[n].centerX = (getWidth());
            if (yFromCent>(getHeight()/2))polygons[n].centerY = 0;
            else if  (yFromCent<-getHeight()/2)polygons[n].centerY = (getHeight());


        }
    }

    double spiregulator = 0;
    void makeSpirograph()
    {
        length = 0;
        phase = 0.;
        links= audioBufferSize;
        //if (maxFreq > 0)while (maxFreq<500) maxFreq*=2;
        float adjConstant = 1./(100)*3.14*1.618;

        for(int m = 0; m < links/1.2; m++)
        {
            if (not(spiraAudio[m]==0 or isinf(spiraAudio[m]) ))
            {
                float samp = (spiraAudio[m]);
                phase += adjConstant;//spira_pitch;
                spirray[length][0]=-sin(phase)*samp;
                spirray[length][1]=-cos(phase)*samp;
                length++;
            }
        }
       
        length -= 1;
        largest_loop = 0;
        spiregulator = 0;
        for(int x = 0; x<length; x++)
        {
            if (x>0)spiregulator +=abs(abs(spiraAudio[x])- abs(spiraAudio[x-1]));
            if (std::abs(spirray[x][0])>largest_loop)largest_loop =
                                                             std::abs(spirray[x][0]);
            if (abs(spirray[x][1])>largest_loop)largest_loop =
                                                        abs(spirray[x][1]);
        }
        spiregulator*=largest_loop;
        spiregulator*=1024/length;
    }



    float cent;
    float counter = 0;
    uint32 lastTime=-1;
    uint32 time;
    float timeDif;
    float callbackWait = 1000/60.f;
    int level = 0;
    int metaLevel=0;
    int polyRad;
    bool playingV = true;
    bool displayCountdown;
    bool back = false;
    ScopedPointer<AudioSourcePlayer> audiosourceplayer1;
    bool firstRun = true;
    void resized() override {

   
    }

    void timerCallback() override
    {
        if (closePressedFor>=2000) back = true;
        shipScale = .54;
        spiroScale = .54;
        if (getHeight()<=getWidth()) minCoord = getHeight();
        else minCoord = getWidth();
       
        if (playingV)   {  shipScale = .8
            ; spiroScale = 1.4;}
        shipScale *= minCoord/750.;
        baseMag = 20*shipScale*dpiScalar;

        if (firstRun){
            firstRun = false;
           
}
        /*
        #if defined JUCE_ANDROID or JUCE_IOS
            if (timeToSleep <Time::currentTimeMillis()) back = true;
            else if (timeToSleep <Time::currentTimeMillis() + 10000) displayCountdown = true;
            else displayCountdown = false;
        #endif
        */
        bool allCaught = true;
        for (int n=0; n<polygons.size(); n++) if(  polygons[n].caught == false) allCaught = false;
        if(allCaught and !playingV)
        {
            if(level >= metaLevel){metaLevel +=1; level = 1;}
            level +=1;
            polygons.clear();
            polygon pol;
            int sides = level+1;
            polyRad = 10*(metaLevel+10)/(metaLevel)*minCoord/300.;
            polPath.clear();
            for (int n = 0; n < sides; n ++)
            {
                if (n == 0) polPath.startNewSubPath( sin(2*pi/sides*n)*polyRad, cos(2*pi/sides*n)*polyRad);
                else polPath.lineTo(sin(2*pi/sides*n)*polyRad, cos(2*pi/sides*n)*polyRad);
            }
           
            polPath.closeSubPath();
            for(int n = 0; n<metaLevel-level; n++)
            {
                pol.centerX = (getWidth())/2+cos(2*pi/((metaLevel-level+2)-2)*n)*(minCoord-polyRad)/2*.7;
                pol.centerY = (getHeight())/2+sin(2*pi/((metaLevel-level+2)-2)*n)*(minCoord-polyRad)/2*.7;
                polygons.push_back(pol);
            }
        }
        else if(playingV) polygons.clear();
        time = Time::currentTimeMillis();
        if(lastTime!=-1)timeDif= time-lastTime;
        else lastTime = 1;
        if(closePressed)closePressedFor+=timeDif;
        if (timeDif <=16) timeDif = 16;
        lastTime = time;

        //while( pool->getNumJobs()>0);
        //spiral_compress3();
        if (nextFFTBlockReady)
        {
            // forwardFFT.performFrequencyOnlyForwardTransform (fftData);
            //spiral_compress2();
            nextFFTBlockReady = false;
        }
        if (nextFFTBlockReady1)
        {
            //  forwardFFT1.performRealOnlyForwardTransform (fftData1,true);
            //for (int b = 0; b<fftSize1; b ++)fftDataC[b] *= -sin(b*pi/fftSize1);

            float last_pitch=pitch;
            pitch =  getPitch(audioBuf);
            float pitchBuffer = pitch;
            if (pitch == -1 and counter <2){counter +=1; pitch=last_pitch;}
            else if(pitch == -2){ pitch = last_pitch;}
            else if(pitch>0){counter = 0;pitch =pow(pitch*3322.4/3951.1,.5);}
            else pitch = 0;
            spira_pitch = pitchBuffer;

            forwardFFT1.performRealOnlyForwardTransform(fftDataC);
            //  for (int i = 0; i < fftSize1; ++i)
            //    fftData11[i] = fftDataC[i];
            //forwardFFT1.performRealOnlyForwardTransform (fftData1);
            spiral_compress();
            nextFFTBlockReady1 = false;
        }
    
       
        move();
        //const MessageManagerLock mmLock;
        repaint();
        // while(pool->getNumJobs()>0);
        startTimer(callbackWait);

    }
    float spira_pitch = 1;

    ~Radial_eq()

    {//adm->removeAudioCallback(&audiosourceplayer1);
        // adm->closeAudioDevice ();
        audiosourceplayer1 = nullptr;
        //openGLContext.detach();
        removeAllChildren();
    }

    int piano[12]={1,0,1,0,1,1,0,1,0,1,0,1};
    int resx;
    int resy;
    bool black = true;
    void paint (Graphics& g) override
    {


        if (backgrounded)
        {g.fillAll(Colours::black);
           
            g.setColour(Colours::white);
            g.setFont(100);
            g.drawMultiLineText     ("Tap\nTo\nGo",
                                     0, 100, getWidth())    ;
        }
        else{
            runTime+=1;
            g.setColour(Colours::white);
            g.fillAll(Colours::grey);
            if(ios){
                            float pressedForScale = (2000-closePressedFor)/2000.;

                float inSlide = minCoord/26.*closePressedFor/2000.;
                float edge = minCoord/26.*pow(2,.5)/2.*pressedForScale;

            if (closePressedFor>2000)closePressedFor = 2000;
                         g.fillEllipse(inSlide,inSlide, minCoord/13.*pressedForScale,minCoord/13.*pressedForScale);

             Path x;

                x.startNewSubPath(minCoord/26.-edge,minCoord/26.-edge);
                                x.lineTo (minCoord/26.+edge,minCoord/26.+edge);
                                            g.setColour(Colours::black);

        g.strokePath(x, PathStrokeType(3.f));
            }
                       Path spirograph;
        makeSpirograph();
        if (spiregulator<.0022)
        {
        int tk = getHeight();
        largest_loop *= 1;
       
        if (tk>getWidth())tk = getWidth();
        float growth = 10;
        if (growth > 1) growth = 1;
       
            for (int n = 0; n < length; n ++) {
                float x = spirray[n][0]/largest_loop*tk/4*spiroScale;
                float y =  spirray[n][1]/largest_loop*tk/4*spiroScale;
               
                if(not(isnan(std::abs(x)) or isnan(std::abs(y)) or abs(x)>getWidth()/2 or  abs(y)>getHeight()/2))
                {
                    if (n == 0) spirograph.startNewSubPath( x+getWidth()/2, y+getHeight()/2);
                    else spirograph.lineTo (x+getWidth()/2,y+getHeight()/2);
                }
                else if (n == 0)  spirograph.startNewSubPath( 0, 0);
            }
           
        }
       
        g.setColour (Colours::white);
            if(black ==true){black=false;g.setColour(Colours::white);}
            else {black = true; g.setColour(Colours::black);}
        g.strokePath(spirograph, PathStrokeType(.7f*spiroScale));
  
            /*
            if (displayCountdown){
                g.setColour(Colours::red);
                g.setFont(50);

                float time = (timeToSleep -Time::currentTimeMillis())/1000.f;
                String warning = String("Pausing \nin: \n") ;
                warning +=String(time);
                warning +=String("\nto go\n on tap");
                g.drawMultiLineText     (warning, 0, 100, getWidth())    ;
            }
            */
            float wd2 =  getWidth()/2.;
            float hd2 =  getHeight()/2.;
            resolution = pow(2,8);



            float f = trail[cycles].radii;
            int n = 0;
            float shiftX2 = 1;
            float shiftY2 = 1;
            while (n<cycles -2)
            {
                Path segment;
                int lastColourIndex = n;

                if (trail[cycles-n].pitchCol.getAlpha()<1 ) while (trail[cycles-n].pitchCol.getAlpha()<1 and n<cycles-1)n++;
                else n++;



            float alpha = trail[cycles-n].pitchCol.getFloatAlpha()*(n)/trailLength;
                float shiftX = wd2 + trail[cycles-n].x;
                float shiftY = hd2 + trail[cycles-n].y;
                Colour colour1 = trail[cycles-n].pitchCol.withAlpha(alpha);


                f = trail[cycles-n].radii;
                segment.startNewSubPath( shiftX+trail[cycles-n].ccwiseX*f, shiftY+trail[cycles-n].ccwiseY*f);
                segment.lineTo(shiftX+trail[cycles-n].cwiseX*f, shiftY+trail[cycles-n].cwiseY*f);

                 lastColourIndex = n;
                while (trail[cycles-n-1].pitchCol.getAlpha()<1 and n<cycles-1)n++;


                float alpha2 = trail[cycles-n-1].pitchCol.getFloatAlpha()*(n-1)/trailLength;

                 shiftX2 = wd2 + trail[cycles-n-1].x;
                 shiftY2 = hd2 + trail[cycles-n-1].y;
                ColourGradient grade = ColourGradient (
                        colour1,
                        shiftX,
                        shiftY,
                        trail[cycles-n-1].pitchCol.withAlpha(alpha2),
                        shiftX2,
                        shiftY2,
                        false
                );
                g.setGradientFill (grade);
                f = trail[cycles-n-1].radii;
                if (cycles - n -1>=2) {
                    segment.lineTo(shiftX2 + trail[cycles - n - 1].cwiseX * f,
                                   shiftY2 + trail[cycles - n - 1].cwiseY * f);

                    segment.lineTo(shiftX2 + trail[cycles - n - 1].ccwiseX * f,
                                   shiftY2 + trail[cycles - n - 1].ccwiseY * f);
                } else {
                    segment.addCentredArc(wd2,
                                          hd2,
                                          trail[cycles - lastColourIndex - 1].radii / 2,
                                          trail[cycles - lastColourIndex - 1].radii / 2,
                                          -trail[cycles - lastColourIndex - 1].angle,
                                          5 / 2. * pi,
                                          3 / 2. * pi

                    );
                    g.setColour(trail[cycles - lastColourIndex].pitchCol.withAlpha(
                            trail[cycles - lastColourIndex].pitchCol.getFloatAlpha()*(lastColourIndex)/trailLength

                            ));
                }

                segment.closeSubPath();

                    g.fillPath(segment);
            }


                // g.fillEllipse(wd2-trail[m].radii/2,hd2-trail[m].radii/2,trail[m].radii, trail[m].radii);



            float amp;
            int incrementation = 22;
            Path star;
            Path stars[12] = {};
            for(int n=0; n<24; ++n)
            {
                bool thi = false;
                // amp = (testar[n]-min1)/(max1-min1);
                int f = 200;

                amp = atan(testar[(n+incrementation)%24]/max1*pi);
                amp = log(testar[(n+incrementation)%24]*f)/log(max1*f);
                amp = atan (amp/3.f)*3;
                //amp = testar[(n+10)%24]/max1;
                float scale = amp*200*shipScale;
                if (scale<.01) scale = .01;
                if (scale>200*shipScale) scale = 200;
                float endX =wd2+ cos(pi2*n/24) * scale;
                float endY =hd2 + sin(pi2*n/24)  * scale;



                if(thi) g.fillEllipse(endX,endY, 10,10);


                if(not(isnan(endX) or isnan(endY) or isinf(endX) or isinf (endY)))
                {
                    star.startNewSubPath (wd2, hd2 );
                    star.lineTo(endX, endY );

                    Colour color = Colour::fromHSV(1-(n-2)%24/24.f    ,
                                                   1.f,1.f,1.0);
                    g.setColour (color);

                    g.strokePath( star, PathStrokeType(14.f*shipScale));
                    star.clear();
                }
            }
            g.setColour (Colours::black);
        }

        g.setColour (Colours::black);
        for (int n = 0; n<polygons.size();n++)
        {
            if (!polygons[n].caught) g.setColour(Colours::white);
            else g.setColour(Colours::black);
            AffineTransform affine;
            g.fillPath(polPath,affine.translated(polygons[n].centerX, polygons[n].centerY));
        }
    }


    int fps;
    int second;
    int  fftspeed = 0;
    double sampleRate = -1;
    int audioBufferSize = -1;
    void load()
    {
        //    pool = new ThreadPool(5);
#if not defined JUCE_IOS
        openGLContext.setMultisamplingEnabled(false);
        openGLContext.setRenderer (this);
        openGLContext.setContinuousRepainting(false);
        openGLContext.attachTo(*this);
#else
        ios = true;

#endif
        setOpaque (true);
        spiral_compress();
        startTimer (1);

    };
    void setSourceWrapper(){      audiosourceplayer1->setSource(this);
    }

    int64 startTime;
    float baseMag;
    Radial_eq() :
            forwardFFT (fftOrder),
            forwardFFT1 (fftOrder1),
            forwardFFT11 (fftOrder1)
    {
        timeToSleep = Time::currentTimeMillis()+timeToLightsOut;
        load();
        audiosourceplayer1 = new AudioSourcePlayer();
    }

    void prepareToPlay (int buffer, double sample) override
    {
        sampleRate = sample;
    }

    void releaseResources() override
    {
    }
    float sourcesLast = 1; void getNextAudioBlock (const AudioSourceChannelInfo& bufferToFill) override
    {
        int bufsiz = bufferToFill.numSamples;
        float timeFactor = sampleRate/44100;
        if (bufferToFill.buffer->getNumChannels() > 0)
        {
            const auto* channelData = bufferToFill.buffer->getReadPointer (0, bufferToFill.startSample);
            if (!backgrounded)
                for (auto i = 0; i < bufferToFill.numSamples; ++i){

                    float b = channelData[i];
                    if(isnan(b))b=0;
                    pushNextSampleIntoFifo(b);

                }

        }
#if defined JUCE_WINDOWS
float buffer[21500];
#else
float buffer[bufferToFill.numSamples];

#endif
        for (int m = 0; m<bufferToFill.numSamples; m++) buffer[m]=0;
        bufferToFill.clearActiveBufferRegion();
        float sources = 0;
        double audioPhaseConstant = (1. / sampleRate * (pi2));

        for (int f = 0; f<10; f++){
            touchPitch t = touchPitches[f];
            if (t.pitchOn or t.pitchJustOff) sources++;
        }
        for (int f = 0; f<10; f++){
            touchPitch t = touchPitches[f];
         /*   if (f == 0){
                DBG("starts here");
                DBG(t.freq);
                DBG(t.angleAmpLast);
            }
          */
            if (t.lastPlayedFreq ==1)t.lastPlayedFreq = t.freq;


            if (t.pitchJustOff ){t.soundJustStarted = false;}
            if (t.pitchJustOff and t.decayBuffer == .0  )
            {t.pitchJustOff = false;}
            if ((t.pitchOn or t.pitchJustOff) and !backgrounded) {
                if(t.freqInterp<1) t.freqInterp = t.freq;

                double bv = audioPhaseConstant* t.freqInterp ;
                int factor = 100;

                double shift = (t.freqInterp-t.freq)*1./ bufferToFill.numSamples*factor;

                float angleAmpAdj =(t.angleAmp + t.ampShift); //*t.freqInterp/t.freq;

                if (t.reduced == "up") {t.ampShift = pi2; }
                else if (t.reduced == "down"){ t.ampShift = -pi2; }
                else if (t.reduced == "not") t.ampShift = 0;

                angleAmpAdj =(t.angleAmp + t.ampShift);// *t.freqInterp/t.freq;
                angleAmpAdj += 2*pi2;
                angleAmpAdj -= (pi2) * trunc(angleAmpAdj / (pi2));
                double ampshiftIncr=0;
                if ( !t.dragging and abs(abs(t.angleAmpLast-angleAmpAdj)-pi2) > .1 and angleAmpAdj !=0 and angleAmpAdj < pi2-.1
                        and angleAmpAdj>.1)
                    ampshiftIncr = (t.angleAmpLast-angleAmpAdj)/ bufferToFill.numSamples*factor;
                else t.angleAmpLast = angleAmpAdj;

                float decayShift = .00002*timeFactor*factor;
                for (auto sample = 0; sample < bufferToFill.numSamples; ++sample) {



                    if(t.sampleNum%factor == 0 or sample==0){

                        t.angleAmpLast -=ampshiftIncr;

                        if (t.pitchJustOff and t.decayBuffer>0)
                            t.decayBuffer -= decayShift;//1 - 1. / (sampleRate) * (framesPassed);
                        else if (t.decayBuffer<1)
                            t.decayBuffer += decayShift;// 1. / (sampleRate) * (sampleRate - framesPassed);
                        if (t.decayBuffer<0.)t.decayBuffer = 0.;
                        else if (t.decayBuffer>1.)t.decayBuffer = 1.;


                        t.freqInterp -= shift;
                        t.phase *= t.freqInterp  / t.lastPlayedFreq;
                        bv = audioPhaseConstant* t.freqInterp;
                        t.lastPlayedFreq = t.freqInterp;
                    }
                    t.phase -= (pi2) * trunc((t.phase) / (pi2));

                    t.sampleNum +=1;

                    t.phase += bv;
                    buffer[sample] +=  (-sin(t.phase  )

                                        * (t.angleAmpLast) / (pi2) +
                                        -sin(t.phase * 2) * (pi2- t.angleAmpLast) / (pi2))*t.decayBuffer;

                }
                t.angleAmpLast = angleAmpAdj;
            }
            //t.angleAmpLast = t.angleAmp*t.freqInterp/t.freq;
            t.lastFreq = t.freq;
            t.freqInterp = t.freq;
            touchPitches[f] =t;

        }
       float totalUnDecayed = 0;
        bool soundOn = false;
        for (int f = 0; f<10; f++){
            touchPitch t = touchPitches[f];
            totalUnDecayed+=t.decayBuffer;
        }
        if (totalUnDecayed>.02) soundOn = true;

            if (totalUnDecayed<1)totalUnDecayed = 1;
            if (soundOn)
        for (auto channel = 0; channel < bufferToFill.buffer->getNumChannels();
             ++channel) {  auto *buffers = bufferToFill.buffer->getWritePointer(channel,
                                                                                bufferToFill.startSample);
            for (auto sample = 0; sample < bufferToFill.numSamples; ++sample)
            {
                buffers [sample]= buffer[sample]/(totalUnDecayed)*.9;
            }}

    }
    //==============================================================================

    float testFreq = 0;





    enum
    {
        fftOrder = 10,
        fftSizr = 16,
        fftSize  = 1<<fftSizr //65536
    };


    enum
    {
        fftOrder1 = 10,
        fftSize1 = 1 << fftOrder1
    };
    float num;
    struct table { float c; float s; float n; float f;};


    Path polPath;

    struct polygon {

        float centerX;
        float centerY;
        float dx=0;
        float dy=0;
        bool caught = false;
        bool exited = true;




    };

    vector<polygon> polygons;
    float maxFrame = 0;
    float lastMaxFrame = 0;

    void pushNextSampleIntoFifo (float sample) noexcept
    {
        if (fifoIndex1 == fftSize1)
        {

            if (! nextFFTBlockReady1)
            {

                zeromem (fftDataC, sizeof (fftDataC));
                memcpy (fftDataC, fifo1, sizeof (fifo1));
                //for (int f = 0; f<bufferSize; f++)fftDataC[f] = -sin(440*pi2*f/sampleRate);
                nextFFTBlockReady1 = true;
                lastMaxFrame = maxFrame;
                //lastMaxFrame /= 2;
                maxFrame = 0;
                for (auto i = 0; i < fftSize1; ++i) if(  fftDataC[i]>maxFrame)maxFrame = fftDataC[i];
                for (auto i = 0; i < fftSize1; ++i) fftDataC[i] /= maxFrame*500;
                for (int f = 0; f<bufferSize; f++){audioBuf[f]=fftDataC[f];spiraAudio[f] =fftDataC[f];}


            }
            fifoIndex1 = 0;
        }
        fifo1[fifoIndex1++] = sample;

    }


    dsp::FFT forwardFFT;
    dsp::FFT forwardFFT1;
    dsp::FFT forwardFFT11;
    Image spectrogramImage;

    float fifo [fftSize];
    float fftData [2 * fftSize];
    int fifoIndex = 0;
    bool nextFFTBlockReady = false;


    float fifo1 [fftSize1];
    float fftData1 [2*fftSize1];
    int fifoIndex1 = 0;
    bool nextFFTBlockReady1 = false;

    float fftDataC [2 * fftSize1];

    OpenGLContext openGLContext;


#define CUTOFF 0.47 //0.97 is default
#define SMALL_CUTOFF .17
#define LOWER_PITCH_CUTOFF 80 //hz

    float getPitch(float *audioBuffer)
    {


        std::vector<float> _nsdf = nsdfFrequencyDomain(audioBuffer);

        std::vector<int> max_positions = peak_picking(_nsdf);

        std::vector<std::pair<float, float>> estimates;

        float highestAmplitude = - 5000000;

        for (auto tau : max_positions)
        {
            highestAmplitude = jmax(highestAmplitude, _nsdf[tau]);

            if (_nsdf[tau] > SMALL_CUTOFF)
            {
                auto x = parabolic_interpolation(_nsdf, tau);
                estimates.push_back(x);
                highestAmplitude = std::max(highestAmplitude, std::get<1>(x));
            }
        }

        if (estimates.empty()) return -1;

        float actualCutoff = CUTOFF * highestAmplitude;
        float period = 1;

        for (auto estimate : estimates)
        {
            if (std::get<1>(estimate) >= actualCutoff)
            {
                period = std::get<0>(estimate);
                break;
            }
        }

        float pitchEstimate = (sampleRate / period);
        // for(int n = 14; n>0; n--)  if (abs(pitchEstimate-pow(2,n))<.1)pitchEstimate=-2;
        if (pitchEstimate> LOWER_PITCH_CUTOFF) return  pitchEstimate;
        else return -1;

    }



    inline std::pair<float, float> parabolic_interpolation(std::vector<float> array, float x)
    {
        int x_adjusted;

        if (x < 1) {
            x_adjusted = (array[x] <= array[x+1]) ? x : x+1;
        } else if (x > signed(array.size())-1) {
            x_adjusted = (array[x] <= array[x-1]) ? x : x-1;
        } else {
            float den = array[x+1] + array[x-1] - 2 * array[x];
            float delta = array[x-1] - array[x+1];
            return (!den) ? std::make_pair(x, array[x]) : std::make_pair(x + delta / (2 * den), array[x] - delta*delta/(8*den));
        }
        return std::make_pair(x_adjusted, array[x_adjusted]);
    }

    static std::vector<int> peak_picking(std::vector<float> nsdf)
    {
        std::vector<int> max_positions{};
        int pos = 0;
        int curMaxPos = 0;
        ssize_t size = nsdf.size();

        while (pos < (size - 1) / 3 && nsdf[pos] > 0) pos++;
        while (pos < size - 1 && nsdf[pos] <= 0.0) pos++;

        if (pos == 0) pos = 1;

        while (pos < size - 1) {
            if (nsdf[pos] > nsdf[pos - 1] && nsdf[pos] >= nsdf[pos + 1]) {
                if (curMaxPos == 0) {
                    curMaxPos = pos;
                } else if (nsdf[pos] > nsdf[curMaxPos]) {
                    curMaxPos = pos;
                }
            }

            pos++;
            if (pos < size - 1 && nsdf[pos] <= 0) {
                if (curMaxPos > 0) {
                    max_positions.push_back(curMaxPos);
                    curMaxPos = 0;
                }
                while (pos < size - 1 && nsdf[pos] <= 0.0) {
                    pos++;
                }
            }
        }
        if (curMaxPos > 0) {
            max_positions.push_back(curMaxPos);
        }
        return max_positions;
    }

    std::vector<float> nsdfFrequencyDomain (const float *audioBuffer)
    {

        std::vector<float> acf (autoCorrelation (audioBuffer));
        return acf;
    }
    std::vector<float> autoCorrelation(const float *audioBuffer)
    {
        float audioProcesse[bufferSize*2];
        for(int l = 0; l<bufferSize; l++) audioProcesse[l] = audioBuf[l]*5000000*-sin(pi*l/bufferSize);
        forwardFFT1.performRealOnlyForwardTransform      (audioProcesse);

        for (int i = 0; i < fftSizep-1; i+=2)
        {

            std::complex<float> complex(audioProcesse[i], audioProcesse[i+1]);
            complex = complex * std::conj(complex);
            audioProcesse[i] = complex.real();
            audioProcesse[i+1] = complex.imag();

        }

        forwardFFT1.performRealOnlyInverseTransform     (audioProcesse)     ;
        vector<float> x;
        for (int i = 0; i < bufferSize; ++i)
            x.push_back( audioProcesse[i]);
        return x;
    }

    static const int fftSizep = fftSize1;
    static const int bufferSize = fftSizep;
    float turningPointX, turningPointY;
    float fftDataB[bufferSize];
    float audioBuf[bufferSize];
    float spiraAudio[bufferSize];

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Radial_eq)
};
#endif  // radial_eq_INCLUDED


